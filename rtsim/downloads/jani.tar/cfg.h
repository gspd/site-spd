/* Header file for control flow graph manager.
   Created: 20-feb-2008
   Last modified: 18-jul-2008
   Author: Willian dos Santos Lima*/

/* ========================================================================= */
#ifndef CFG
#define CFG

/* ------------------------------------------------------------------------- */

/* function to create the control flow graph*/
char cfg_gen ( const TInstr *int_code, u4 code_length, boolean file_gen );

/* function to find the basic blocks*/
char cfg_find_basic_blocks ( const TInstr *int_code, u4 code_length );

/* ------------------------------------------------------------------------- */
/* CFG global variables declaration*/

/* the so-called Control Flow Graph -----------------------------------------*/
TCFG cfg;

/* function to return a pointer for CFG to other modules*/
TCFG* cfg_get ( void );

/*TBasicBlock *cfg;
u4 cfg_length;    /* measured in numbers of basic blocks*/

/*TBasicBlock* cfg_get ( u4 *cfglen );
/* ------------------------------------------------------------------------- */

/* map: instruction -> basic block*/
/*s4 *basic_block_of;

/* ========================================================================= */

#include "cfg.c"

/* ========================================================================= */

#endif
